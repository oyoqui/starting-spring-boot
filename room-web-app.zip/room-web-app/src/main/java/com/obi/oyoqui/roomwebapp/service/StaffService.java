package com.obi.oyoqui.roomwebapp.service;

import com.obi.oyoqui.roomwebapp.entity.Position;
import com.obi.oyoqui.roomwebapp.entity.StaffMember;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class StaffService {
    private static final List<StaffMember> staff = new ArrayList<>();

    static {
        staff.add(new StaffMember(UUID.randomUUID().toString(), "Pedro", "Perez", Position.CONCIERGE));
        staff.add(new StaffMember(UUID.randomUUID().toString(), "Karol", "Aguilera", Position.FRONT_DESK));
        staff.add(new StaffMember(UUID.randomUUID().toString(), "Jorge", "Oyoqui", Position.SECURITY));
        staff.add(new StaffMember(UUID.randomUUID().toString(), "Daniel", "Sanchez", Position.HOUSEKEEPING));
    }

    public List<StaffMember> getAllStaff() { return  staff; }
}
