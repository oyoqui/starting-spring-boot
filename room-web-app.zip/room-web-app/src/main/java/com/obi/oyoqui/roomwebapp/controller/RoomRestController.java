package com.obi.oyoqui.roomwebapp.controller;

import com.obi.oyoqui.roomwebapp.entity.Room;
import com.obi.oyoqui.roomwebapp.service.RoomServices;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/rooms")
public class RoomRestController {
    private final RoomServices roomServices;

    public RoomRestController(RoomServices roomServices) {
        this.roomServices = roomServices;
    }

    @GetMapping
    public List<Room> getAllRooms() {
        return roomServices.getAllRooms();
    }
}
