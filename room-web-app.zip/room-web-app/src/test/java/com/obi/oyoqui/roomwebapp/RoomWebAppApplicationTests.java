package com.obi.oyoqui.roomwebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoomWebAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
